from setuptools import setup

setup(

    name="paquetes_distribuibles",
    version="1.0",
    descripcion="ejemplo de paquete distribuible",
    author="mgf",
    author_email="marcos@gmail.com",
    url="www.google.es",
    packages=["modulos"]
)
