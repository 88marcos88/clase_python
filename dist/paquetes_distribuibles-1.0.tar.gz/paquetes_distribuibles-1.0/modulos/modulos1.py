def sumar(s1, s2):

    print(s1+s2)


def restar(s1, s2):

    print(s1-s2)


def multiplicar(s1, s2):

    print(s1*s2)
